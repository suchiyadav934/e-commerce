import { createContext } from "react";

const userContext1 = createContext()

export default userContext1