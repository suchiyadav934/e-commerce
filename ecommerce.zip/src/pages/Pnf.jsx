import React from 'react';

const Pnf = () => {
  return (
    <div>
      pnf
    </div>
  );
}

export default Pnf;
