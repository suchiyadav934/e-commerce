import React from 'react'
import { Link, useLocation } from 'react-router-dom'

const ViewDetails = () => {
  const location = useLocation();
  console.log(location)
  let view = location.state;

  let star = '';
  let temp = Math.round(view.rating)
  for (let i = 1; i <= temp; i++) {
    star += '⭐'
  }

  return (
    <div className='container' style={{ marginTop: '70px' }}>
      <div className='row'>
        <div className='col-md-6 d-flex rounded bg-warning'><img src={location.state.thumbnail} alt="" />
          <div className=' col-md-6 bg-white text-dark d-flex flex-column justify-content-center rounded my-4' style={{ height: '', width: '', marginTop: '', textAlign: 'center' }}>
            <h4 className="card-title">{view.title}</h4>
            <p className="card-text"><b>Price</b> : {view.price} $ </p>
            <p className="card-text mt-4"><b>Brand</b> : {view.brand}</p>
            <p className="card-text"><b>Category</b> : {view.category}</p>
            <p className="card-text"><b>Rating</b> : {star}</p>

          </div>
        </div>

      </div>
    </div>
  )
}

export default ViewDetails